var streamerUsername = 'Will_Boss_Gamer';

function User(data){
  chrome.storage.local.set({ avatarURL: data.UserInfo.avatar });
}

function Live(isLive, data){
  if(isLive == true){
    
    chrome.storage.local.get(['streamID'], function(streamID) {

      if(streamID.streamID != data.liveInfo.stream_id){

        chrome.storage.local.get(['avatarURL'], function(avatar) {
          var thumbnail = data.liveInfo.thumbnail_url;
          var backgroundURL = thumbnail.replace("{width}", "1920").replace("{height}", "1080");
          var avatarNotif = avatar.avatarURL;
          if(avatar.avatarURL == undefined){
            avatarNotif = "../Images/avatar.png"
          }
          createImageNotification(data.liveInfo.title, backgroundURL, avatar.avatarURL, data.liveInfo.game_name, [{ title: "Regarder le stream", iconUrl: "../Images/twitch.png" }])
          chrome.storage.local.set({ streamID: data.liveInfo.stream_id });
        })
          
      }
    });
  }
}

function createImageNotification(message, imageURL, iconURL, contextMessage, buttons){

  if(imageURL == "" || imageURL == undefined){
    imageURL = "../Images/background.png"
  }
  if(iconURL == "" || iconURL == undefined){
    iconURL = "../Images/avatar.png"
  }

  chrome.notifications.create({
    type: "image",
    title: "Will_Boss_Gamer est en live !",
    message: message,
    imageUrl: imageURL,
    iconUrl: iconURL,
    contextMessage: "Joue à " + contextMessage,
    buttons: buttons,
    silent: false,
    priority: 2
  });
  alarmNotification()
}

function alarmNotification(){
  var alarm = "1"
  chrome.storage.local.get(['alarm'], function(result) {
    if(result.alarm != undefined){
      alarm = result.alarm
    }
  });
}

function verifyTwitchLive(){
  var url = 'https://willbosstwitchbot.glitch.me/twitch?stream=' + streamerUsername;
  
  fetch(url, {
    method: 'GET',
  })
  .then(function(response) {
    return response.json();
  })
  .then(function(data) {
    Live(data.live, data)
  })
  .catch(function(error) {
    console.log('Error: ' + error);
  });
}

function getUser(){
  var url = 'https://willbosstwitchbot.glitch.me/twitch?user=' + streamerUsername;
  
  fetch(url, {
    method: 'GET',
  })
  .then(function(response) {
    return response.json();
  })
  .then(function(data) {
    User(data)
  })
  .catch(function(error) {
    console.log('Error: ' + error);
  });
}

setInterval(function() {
  console.log("Envoie d'envoie")
  getUser();
  verifyTwitchLive();
}, 5000);